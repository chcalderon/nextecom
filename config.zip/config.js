const DB_URI="mongodb+srv://ripsode:i.5N-ywgJfL3wXE@cluster0.hvbr8.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

const DB_URI_LOCAL="mongodb://localhost:27017/"

module.exports = {
    DB_URI,
    DB_URI_LOCAL,
}